#!/bin/bash
sudo systemctl restart lightdm.service
